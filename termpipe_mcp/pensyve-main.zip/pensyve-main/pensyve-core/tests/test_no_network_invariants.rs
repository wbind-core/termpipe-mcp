#![allow(
    clippy::doc_markdown,
    reason = "documentary test module: bare-word product names like SQLite/HTTP appear in narrative prose where backtick noise outweighs linter pedantry"
)]
//! No-network-invariant tests for operators that pre-reg G1 §2 invariant I4
//! documents as no-op under `NetworkPolicy` enforcement (`Reranker`,
//! `OnnxEmbedder` per-call inference, `PeerCard`).
//!
//! These tests exist to **prevent regression**: if a future code change
//! introduces a network call into any of these operators, the test fails
//! and the no-op invariant must be revisited via a Phase G1 addendum
//! (`pensyve-docs/research/benchmark-sprint/v3/g1/addendum_NN.md`).
//!
//! ## Reference
//!
//! - Pre-reg: `pensyve-docs/research/benchmark-sprint/v3/g1/preregistration.md`
//!   §2 invariant I4 (per-operator audit table), §3.0 item 10, §5.4.
//! - Production sources verified at draft time:
//!   - `pensyve-core/src/reranker.rs:83` — `Reranker::new(model_name)` →
//!     pure `fastembed` ONNX inference; the only network call is the
//!     load-time HF model download via `RerankInitOptions`.
//!   - `pensyve-core/src/embedding.rs:101` — `OnnxEmbedder::new(model_name)`
//!     → load-time HF model download (one-shot, cached); per-call `embed()`
//!     is pure ONNX inference.
//!   - `pensyve-core/src/peer_card.rs:56-60` — `Connection::open_with_flags`
//!     with `SQLITE_OPEN_READ_ONLY`; pure SQLite, zero HTTP anywhere.
//!
//! ## Methodology — Approach C (constructive + documentary, with cache hermeticity)
//!
//! Three approaches were considered for asserting "zero network calls":
//!
//! - **Approach A** (environmental network blocking via `iptables` /
//!   `cargo nextest --no-capture` with a sandbox): requires CI changes
//!   and is not portable to developer machines.
//! - **Approach B** (replacing `reqwest`'s default client with a panicking
//!   one): requires production-code injection points that don't exist
//!   today and would be a large surface change for a documentary test.
//! - **Approach C** (constructive call + import hygiene + cache pre-condition):
//!   pick a model that's *already cached locally* so the load-time HF
//!   download path is provably never reached; call the operator and
//!   assert success; combine with `#[deny(unused_imports)]` against any
//!   HTTP-client crate `use` line that might appear in this file in the
//!   future. The PRIMARY value is that the test exists and is documented
//!   as a no-network invariant; the secondary value is that the absence
//!   of any HTTP-client `use` line is mechanically enforced for *this
//!   file* via `deny(unused_imports)`.
//!
//! Approach C was chosen.
//!
//! ## Cache pre-condition
//!
//! `fastembed` 6.0.1 resolves its effective cache via `HF_HOME` when set,
//! otherwise the `FASTEMBED_CACHE_DIR` option, which defaults to
//! `.fastembed_cache` in the current working directory. When `cargo test`
//! runs from `pensyve-core/`, the cwd is `pensyve-core/`, and the
//! workspace ships a populated `pensyve-core/.fastembed_cache/` containing
//! at least:
//!   - `models--BAAI--bge-reranker-base/`
//!   - `models--Qdrant--all-MiniLM-L6-v2-onnx/`
//!
//! Tests that need the cache present run unconditionally; tests that
//! exercise the *absence* of the cache (constructor under `Disabled` with
//! uncached model) build a private tempdir cache and override the env var
//! for the duration of the call.

// --- Import hygiene guard ------------------------------------------------
//
// This file is documentary: NO HTTP-client crate should ever appear in
// the `use` block. `#[deny(unused_imports)]` would not catch a deliberate
// import; a stronger mechanical check would require `static_assertions`
// or a custom build-script. The lint we DO get for free is that any
// `reqwest` / `ureq` / `hyper` / `http_client` import added here will be
// visible in code review. If you are reading this comment because such an
// import landed, please STOP and revisit the no-op invariant first.
// -------------------------------------------------------------------------

use std::path::{Path, PathBuf};
use std::sync::{Mutex, OnceLock};

use pensyve_core::embedding::{EmbeddingError, OnnxEmbedder};
use pensyve_core::network_policy::NetworkPolicy;
use pensyve_core::peer_card::{PEER_CARD_FOOTER, PEER_CARD_HEADER, build_peer_card};
use pensyve_core::reranker::Reranker;
use rusqlite::Connection;
use tempfile::TempDir;

/// Process-wide mutex serializing every test in this file that either
/// mutates `FASTEMBED_CACHE_DIR` or loads a model through fastembed (which
/// reads that same process-global env var internally). Without this,
/// parallel test execution can race: one test sets the var to a tempdir
/// while another test — even one that never touches the var itself —
/// concurrently loads a cached model and reads the tempdir instead of the
/// real cache, producing a spurious `ModelLoad("Failed to retrieve
/// model.onnx")`-style failure that looks like a cache-resolution
/// regression but is actually this race. (This is suspected to be the
/// real explanation for the once-reported 5.17.2 -> 5.17.3 "regression";
/// see the comment on the `fastembed` dependency in
/// `pensyve-core/Cargo.toml`.) cargo's default test runner gives no
/// ordering guarantee inside a single test binary, hence the mutex.
fn cache_env_lock() -> &'static Mutex<()> {
    static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
    LOCK.get_or_init(|| Mutex::new(()))
}

/// Absolute, snapshot path of the real fastembed cache dir, captured
/// at first call BEFORE any test mutates `FASTEMBED_CACHE_DIR`. Used
/// by the `cached`-variant test so it can pin the env var to the real
/// cache regardless of what other tests have done concurrently.
fn real_cache_dir() -> &'static Path {
    static REAL: OnceLock<PathBuf> = OnceLock::new();
    REAL.get_or_init(|| {
        let raw = std::env::var("HF_HOME")
            .or_else(|_| std::env::var("FASTEMBED_CACHE_DIR"))
            .unwrap_or_else(|_| ".fastembed_cache".into());
        let p = PathBuf::from(raw);
        // Canonicalize if possible so the snapshot is robust against
        // later cwd changes; fall back to the lexical path otherwise.
        std::fs::canonicalize(&p).unwrap_or(p)
    })
}

// -------------------------------------------------------------------------
// Cache pre-condition helpers
// -------------------------------------------------------------------------

/// `BAAI/bge-reranker-base` cache directory name as fastembed lays it
/// down on disk (see `pensyve-core/.fastembed_cache/`).
const BGE_RERANKER_CACHE_DIR: &str = "models--BAAI--bge-reranker-base";

const BGE_RERANKER_REQUIRED_FILES: &[&str] = &[
    "config.json",
    "onnx/model.onnx",
    "special_tokens_map.json",
    "tokenizer.json",
    "tokenizer_config.json",
];

/// `Qdrant/all-MiniLM-L6-v2-onnx` cache directory name (the fastembed
/// canonical mapping for our exposed `"all-MiniLM-L6-v2"` model name).
const MINILM_CACHE_DIR: &str = "models--Qdrant--all-MiniLM-L6-v2-onnx";

const MINILM_REQUIRED_FILES: &[&str] = &[
    "config.json",
    "model.onnx",
    "special_tokens_map.json",
    "tokenizer.json",
    "tokenizer_config.json",
];

/// Resolve the effective cache dir the same way fastembed 6.0.1's
/// `pull_from_hf` does (`HF_HOME`, then its `FASTEMBED_CACHE_DIR`-derived
/// option, then `.fastembed_cache`) and check that the named subdir exists.
/// If it doesn't, we skip the test rather than
/// fail — the cache is a developer-environment precondition, not a
/// production-code invariant.
fn fastembed_cache_has(model_subdir: &str) -> bool {
    let cache_dir = std::env::var("HF_HOME")
        .or_else(|_| std::env::var("FASTEMBED_CACHE_DIR"))
        .unwrap_or_else(|_| ".fastembed_cache".into());
    Path::new(&cache_dir).join(model_subdir).is_dir()
}

/// Seed an isolated BGE cache from a real local snapshot using symlinks.
/// The source cache remains read-only; the returned snapshot can be mutated
/// to exercise cache completeness without copying or modifying the ONNX blob.
#[cfg(unix)]
fn seed_bge_cache(source_root: &Path, destination_root: &Path) -> PathBuf {
    let source_repository = source_root.join(BGE_RERANKER_CACHE_DIR);
    let revision = std::fs::read_to_string(source_repository.join("refs/main"))
        .expect("read seeded BGE main ref");
    let destination_repository = destination_root.join(BGE_RERANKER_CACHE_DIR);
    std::fs::create_dir_all(destination_repository.join("refs")).expect("create seeded BGE refs");
    std::fs::write(destination_repository.join("refs/main"), &revision)
        .expect("write seeded BGE main ref");

    let source_snapshot = source_repository.join("snapshots").join(&revision);
    let destination_snapshot = destination_repository.join("snapshots").join(&revision);
    for required in BGE_RERANKER_REQUIRED_FILES {
        let source = std::fs::canonicalize(source_snapshot.join(required))
            .unwrap_or_else(|_| panic!("resolve real cached BGE file {required}"));
        let destination = destination_snapshot.join(required);
        std::fs::create_dir_all(destination.parent().expect("required file parent"))
            .expect("create seeded BGE snapshot directory");
        std::os::unix::fs::symlink(source, destination).expect("symlink real cached BGE file");
    }
    destination_snapshot
}

/// Seed an isolated MiniLM cache from a real local snapshot using symlinks.
/// The source cache remains read-only; the returned snapshot can be mutated
/// to prove cached construction revalidates the active cache.
#[cfg(unix)]
fn seed_minilm_cache(source_root: &Path, destination_root: &Path) -> PathBuf {
    let source_repository = source_root.join(MINILM_CACHE_DIR);
    let revision = std::fs::read_to_string(source_repository.join("refs/main"))
        .expect("read seeded MiniLM main ref");
    let destination_repository = destination_root.join(MINILM_CACHE_DIR);
    std::fs::create_dir_all(destination_repository.join("refs"))
        .expect("create seeded MiniLM refs");
    std::fs::write(destination_repository.join("refs/main"), &revision)
        .expect("write seeded MiniLM main ref");

    let source_snapshot = source_repository.join("snapshots").join(&revision);
    let destination_snapshot = destination_repository.join("snapshots").join(&revision);
    for required in MINILM_REQUIRED_FILES {
        let source = std::fs::canonicalize(source_snapshot.join(required))
            .unwrap_or_else(|_| panic!("resolve real cached MiniLM file {required}"));
        let destination = destination_snapshot.join(required);
        std::fs::create_dir_all(destination.parent().expect("required file parent"))
            .expect("create seeded MiniLM snapshot directory");
        std::os::unix::fs::symlink(source, destination).expect("symlink real cached MiniLM file");
    }
    destination_snapshot
}

// -------------------------------------------------------------------------
// Reranker
// -------------------------------------------------------------------------

/// **Invariant I4.Reranker**:
/// `Reranker::new_cached_with_policy("BGERerankerBase", &NetworkPolicy::Disabled)`
/// followed by a `rerank()` call MUST NOT make any network request when
/// the model is already cached locally. Per pre-reg §2 I4: "pure ONNX inference
/// (`fastembed`); NO network calls today. G1 invariant: documented no-op;
/// unit test asserts no network access regardless of policy state."
///
/// Mechanical proof:
///   1. The fastembed cache contains `models--BAAI--bge-reranker-base/`
///      (skipped otherwise — developer environment precondition).
///   2. `Reranker::new_cached_with_policy(..., &NetworkPolicy::Disabled)`
///      succeeds. The disabled policy makes any online fallback a test
///      failure, so construction proves the real model loaded from cache.
///   3. `rerank(query, docs, top_k)` returns successfully — pure ONNX
///      inference path, zero network awareness in the call graph.
///   4. Repointing the process cache to an empty tempdir makes a second
///      cached construction fail, proving an Arc loaded under the first
///      root cannot bypass policy checks under another root.
///   5. This file imports zero HTTP-client crates (see import-hygiene
///      guard at the top). If a future change to `Reranker` introduces
///      a `reqwest::get(...)` call inside `rerank()`, that call would
///      need to be added to the production source AND the test would
///      need to be updated to acknowledge the new surface — at which
///      point the no-op invariant is broken and an addendum is required.
#[test]
#[cfg(unix)]
fn reranker_does_not_make_network_calls() {
    let real = real_cache_dir().to_path_buf();
    // Acquire the same env-var lock the other cache-policy tests use below.
    // The cache environment is process-global; without this, cargo's
    // parallel test runner could interleave this test with one of the
    // tests that temporarily points the var at an empty tempdir, causing
    // this cache-hit call to spuriously read the wrong directory and fail
    // with a `ModelLoad` error that looks like a real cache-resolution
    // regression but is actually a test-harness race. This test pins the
    // cache twice below, so the lock covers both environment guards.
    let _serial = cache_env_lock().lock().expect("env lock poisoned");

    if !real.join(BGE_RERANKER_CACHE_DIR).is_dir() {
        eprintln!(
            "skipping reranker_does_not_make_network_calls: \
             {BGE_RERANKER_CACHE_DIR} not in fastembed cache at {}. \
             Pre-cache it with `cargo test -p pensyve-core --release --test test_no_network_invariants -- --ignored` \
             or run `Reranker::new(\"BGERerankerBase\")` once with network access.",
            real.display()
        );
        return;
    }

    let seeded_cache = TempDir::new().expect("isolated seeded BGE cache");
    let seeded_snapshot = seed_bge_cache(&real, seeded_cache.path());
    let real_cache_guard = FastembedCacheGuard::set(seeded_cache.path());
    let reranker = Reranker::new_cached_with_policy("BGERerankerBase", &NetworkPolicy::Disabled)
        .expect("BGE reranker should construct from cache under Disabled");
    let query = "What is the capital of France?";
    let docs = [
        "Paris is the capital of France.",
        "Berlin is the capital of Germany.",
        "The Eiffel Tower is located in Paris.",
    ];
    let results = reranker
        .rerank(query, &docs, 3)
        .expect("rerank against cached model should succeed without network");

    // Sanity: the call returned the requested top_k entries.
    assert_eq!(
        results.len(),
        3,
        "rerank should return all 3 docs at top_k=3"
    );
    // Scores are well-defined; the most-relevant doc (Paris-as-capital)
    // should outrank the Berlin doc. We don't assert a specific ordering
    // (cross-encoder scores vary across builds); we only assert the call
    // executed successfully end-to-end against ONNX, proving the path
    // was inference-only.
    assert!(
        results.iter().all(|r| r.score.is_finite()),
        "all scores should be finite floats — sanity check that ONNX returned real numbers"
    );

    // Even a same-root Arc hit must honor Disabled cache completeness after
    // a runtime file disappears.
    std::fs::remove_file(seeded_snapshot.join("tokenizer_config.json"))
        .expect("remove required file from isolated cache");
    match Reranker::new_cached_with_policy("BGERerankerBase", &NetworkPolicy::Disabled) {
        Err(error) if error.is_cache_error() => assert!(
            error.to_string().contains("tokenizer_config.json"),
            "expected removed-file cache error, got: {error}"
        ),
        Err(other) => panic!("expected cache-specific error after file removal, got {other:?}"),
        Ok(_) => panic!("same-root cached Arc bypassed Disabled cache preflight"),
    }

    // Nor may the Arc satisfy construction after the process cache is
    // repointed at a distinct empty root. Drop the first environment guard
    // before installing the second one; the Arc intentionally remains alive.
    drop(real_cache_guard);
    let empty_cache = TempDir::new().expect("empty fastembed cache");
    let _empty_cache = FastembedCacheGuard::set(empty_cache.path());
    match Reranker::new_cached_with_policy("BGERerankerBase", &NetworkPolicy::Disabled) {
        Err(error) if error.is_cache_error() => assert!(
            error.to_string().contains("refs/main"),
            "expected missing-ref cache error, got: {error}"
        ),
        Err(other) => panic!("expected cache-specific error under empty cache, got {other:?}"),
        Ok(_) => panic!(
            "cached Arc from a different FASTEMBED_CACHE_DIR bypassed Disabled cache preflight"
        ),
    }
}

// -------------------------------------------------------------------------
// OnnxEmbedder — per-call inference
// -------------------------------------------------------------------------

/// **Invariant I4.OnnxEmbedder.per-call**: After a successful
/// `OnnxEmbedder::new(...)` (which may have done the one-shot HF download
/// at load-time), every subsequent `embed(...)` call MUST NOT make any
/// network request. Per pre-reg §2 I4: "load-time HF model download at
/// `embedding.rs:121-126` (one-shot, cached); per-call inference has NO
/// network. G1 invariant: load-time download denied under `Disabled` at
/// constructor; per-call no-op."
///
/// Mechanical proof:
///   1. The fastembed cache contains the MiniLM ONNX subdir (skipped
///      otherwise).
///   2. `OnnxEmbedder::new("all-MiniLM-L6-v2")` succeeds — load-time
///      path resolves from cache, no HF round-trip needed.
///   3. Multiple `embed(...)` calls succeed. If any per-call surface
///      were to introduce HTTP, those calls would need a runtime client
///      construction — none exists in `EmbedderInner::Real::embed()`
///      (verified against `embedding.rs:173-190` at draft time).
///   4. Import-hygiene guard at top of file applies.
#[test]
fn onnx_embedder_per_call_inference_makes_no_network_calls() {
    // See the identical lock rationale in `reranker_does_not_make_network_calls`
    // above: this test never mutates `FASTEMBED_CACHE_DIR` but must not run
    // concurrently with a test that does, or a global-env-var race can make
    // a cache-hit load spuriously fail.
    let _serial = cache_env_lock().lock().expect("env lock poisoned");

    if !fastembed_cache_has(MINILM_CACHE_DIR) {
        eprintln!(
            "skipping onnx_embedder_per_call_inference_makes_no_network_calls: \
             {MINILM_CACHE_DIR} not in fastembed cache. Pre-cache by running \
             `OnnxEmbedder::new(\"all-MiniLM-L6-v2\")` once with network access."
        );
        return;
    }

    let embedder =
        OnnxEmbedder::new("all-MiniLM-L6-v2").expect("MiniLM embedder should construct from cache");

    // Several `embed` calls in sequence — the per-call surface is what
    // we're attesting has no network awareness. Each call exercises the
    // pool-rotation path at `embedding.rs:177` (`fetch_add` + `pool[idx]`),
    // proving the per-call dispatch reaches `model.embed(...)` directly
    // without re-entering any constructor or download path.
    let inputs = [
        "the quick brown fox jumps over the lazy dog",
        "Pensyve is a universal memory runtime for AI agents",
        "no network calls should occur during inference",
        "fastembed wraps ONNX Runtime for sentence embeddings",
    ];
    for text in &inputs {
        let embedding = embedder
            .embed(text)
            .expect("embed should succeed without network");
        assert_eq!(
            embedding.len(),
            384,
            "MiniLM-L6-v2 should return 384-dim embeddings"
        );
        // Norm sanity — fastembed returns unit-normalized vectors. If
        // the call had been short-circuited to a network error and the
        // embedder had silently fallen back to mock (it doesn't — but
        // future regressions might), the norm would still be 1.0 from
        // mock_embed; the dimension check above protects against that
        // because mock_embed honors the requested dims.
        let norm: f32 = embedding.iter().map(|x| x * x).sum::<f32>().sqrt();
        assert!(
            (norm - 1.0).abs() < 0.05,
            "embedding should be roughly unit-normalized; got norm={norm}"
        );
    }
}

/// **Invariant I4.OnnxEmbedder.constructor-disabled-uncached**: under
/// `NetworkPolicy::Disabled`, attempting to construct an `OnnxEmbedder`
/// for a model that requires HF download MUST return a network-shaped
/// error and leave no partial download artifact on disk.
///
/// Per pre-reg §3.0 item 10: "OnnxEmbedder constructor under Disabled
/// with NON-cached model: assert NetworkRequiredError." The production
/// surface gained `OnnxEmbedder::new_with_policy(model, &policy)` (see
/// `embedding.rs`), which fires `policy.check(<HF_URL>)` whenever the
/// model is absent from the fastembed cache.
///
/// Mechanical proof:
///   1. Point `FASTEMBED_CACHE_DIR` at a fresh tempdir — guarantees the
///      model is NOT cached.
///   2. Call `new_with_policy(<model>, &NetworkPolicy::Disabled)`.
///   3. Assert the result is `Err(EmbeddingError::Network(_))`.
///   4. Assert the cache tempdir has no `models--*` subdirectory —
///      proves the policy gate fired BEFORE any download attempt and
///      that no partial-download artifact was left behind.
///
/// `# Safety` note on `set_var`: this test serializes its env-var
/// mutation by running `cargo test` single-threaded for env-var-using
/// tests (the cached/uncached variants both touch
/// `FASTEMBED_CACHE_DIR`). The pair is paired by name so a future
/// reader can see they MUST run sequentially; cargo's default test
/// runner gives no such guarantee, so we use `serial_test`-style
/// hygiene: restore the previous value in a `Drop` guard.
#[test]
fn onnx_embedder_constructor_under_disabled_with_uncached_model_returns_error() {
    // Snapshot the real cache dir before we mutate the env var, so the
    // sibling cached-variant test can recover it deterministically.
    let _ = real_cache_dir();
    let _serial = cache_env_lock().lock().expect("env lock poisoned");

    let cache_tempdir = TempDir::new().expect("tempdir for empty fastembed cache");
    let _guard = FastembedCacheGuard::set(cache_tempdir.path());

    let result =
        OnnxEmbedder::new_with_policy("Alibaba-NLP/gte-base-en-v1.5", &NetworkPolicy::Disabled);

    match result {
        Err(EmbeddingError::Network(msg)) => {
            assert!(
                msg.contains("Disabled") || msg.contains("not permitted"),
                "expected Disabled-policy error message, got: {msg}"
            );
        }
        Err(other) => panic!(
            "expected EmbeddingError::Network for uncached model under Disabled, \
             got {other:?}"
        ),
        Ok(_) => panic!(
            "constructor succeeded under Disabled with empty cache — \
             load-time download was either silently skipped or completed; \
             either way the no-network invariant is broken"
        ),
    }

    // No partial download artifact left on disk: the cache tempdir
    // should contain no `models--*` subdirectory because the policy
    // gate fires BEFORE fastembed's `pull_from_hf` is invoked.
    let entries: Vec<_> = std::fs::read_dir(cache_tempdir.path())
        .expect("read tempdir")
        .filter_map(Result::ok)
        .filter(|e| e.file_name().to_string_lossy().starts_with("models--"))
        .collect();
    assert!(
        entries.is_empty(),
        "expected no model subdirectory after denied download, found: {entries:?}"
    );
}

/// **Invariant I4.OnnxEmbedder.constructor-disabled-cached**: under
/// `NetworkPolicy::Disabled`, constructing an `OnnxEmbedder` for a
/// model that IS already cached locally MUST succeed — the constructor
/// reads the cache without any HF round-trip, so the policy gate is a
/// no-op (the gate only fires when a download would actually happen).
///
/// Mechanical proof:
///   1. The fastembed cache contains `models--Qdrant--all-MiniLM-L6-v2-onnx/`
///      (skipped otherwise — developer environment precondition).
///   2. `new_with_policy("all-MiniLM-L6-v2", &NetworkPolicy::Disabled)`
///      succeeds. The policy check inside the constructor short-circuits
///      because `is_model_cached` returns true.
///   3. A subsequent `embed(...)` call returns a 384-dim vector,
///      proving the constructor produced a fully-functional embedder
///      from the cache alone.
#[test]
fn onnx_embedder_constructor_under_disabled_with_cached_model_succeeds() {
    // Snapshot the real cache dir BEFORE acquiring the env lock so we
    // never read a value that was temporarily set by the uncached
    // sibling test.
    let real = real_cache_dir().to_path_buf();
    if !real.join(MINILM_CACHE_DIR).is_dir() {
        eprintln!(
            "skipping onnx_embedder_constructor_under_disabled_with_cached_model_succeeds: \
             {MINILM_CACHE_DIR} not in fastembed cache at {}. \
             Pre-cache by running `OnnxEmbedder::new(\"all-MiniLM-L6-v2\")` \
             once with network access.",
            real.display()
        );
        return;
    }

    // Serialize against the uncached-sibling test, then pin the env
    // var to the snapshotted real cache for the duration of the
    // constructor call.
    let _serial = cache_env_lock().lock().expect("env lock poisoned");
    let _guard = FastembedCacheGuard::set(&real);

    let embedder = OnnxEmbedder::new_with_policy("all-MiniLM-L6-v2", &NetworkPolicy::Disabled)
        .expect("cached model should construct under Disabled");

    let embedding = embedder.embed("hello").expect("embed should succeed");
    assert_eq!(
        embedding.len(),
        384,
        "MiniLM-L6-v2 should return 384-dim embeddings"
    );
}

/// A process-cached embedder must not bypass the active cache certification
/// required by `NetworkPolicy::Disabled`. Both a required file disappearing
/// from the original root and switching to a distinct empty root must fail
/// before a cached `Arc<OnnxEmbedder>` is returned.
#[test]
#[cfg(unix)]
fn onnx_embedder_cached_disabled_revalidates_active_cache() {
    let real = real_cache_dir().to_path_buf();
    if !real.join(MINILM_CACHE_DIR).is_dir() {
        eprintln!(
            "skipping onnx_embedder_cached_disabled_revalidates_active_cache: \
             {MINILM_CACHE_DIR} not in fastembed cache at {}. \
             Pre-cache by running `OnnxEmbedder::new(\"all-MiniLM-L6-v2\")` \
             once with network access.",
            real.display()
        );
        return;
    }
    let _serial = cache_env_lock().lock().expect("env lock poisoned");

    let seeded_cache = TempDir::new().expect("isolated seeded MiniLM cache");
    let seeded_snapshot = seed_minilm_cache(&real, seeded_cache.path());
    let seeded_guard = FastembedCacheGuard::set(seeded_cache.path());
    let cached = OnnxEmbedder::new_cached_with_policy("all-MiniLM-L6-v2", &NetworkPolicy::Disabled)
        .expect("complete seeded cache should initialize under Disabled");
    assert_eq!(cached.dimensions(), 384);

    std::fs::remove_file(seeded_snapshot.join("tokenizer_config.json"))
        .expect("remove required file from isolated MiniLM cache");
    let same_root =
        OnnxEmbedder::new_cached_with_policy("all-MiniLM-L6-v2", &NetworkPolicy::Disabled);

    drop(seeded_guard);
    let empty_cache = TempDir::new().expect("distinct empty MiniLM cache");
    let _empty_guard = FastembedCacheGuard::set(empty_cache.path());
    let distinct_root =
        OnnxEmbedder::new_cached_with_policy("all-MiniLM-L6-v2", &NetworkPolicy::Disabled);

    let mut failures = Vec::new();
    match same_root {
        Err(error)
            if error.is_cache_error() && error.to_string().contains("tokenizer_config.json") => {}
        Err(error) => failures.push(format!("same root returned the wrong error: {error}")),
        Ok(_) => failures.push("same-root cached Arc bypassed required-file preflight".to_string()),
    }
    match distinct_root {
        Err(error) if error.is_cache_error() && error.to_string().contains("refs/main") => {}
        Err(error) => failures.push(format!("distinct root returned the wrong error: {error}")),
        Ok(_) => failures.push("cached Arc from another cache root bypassed preflight".to_string()),
    }
    assert!(
        failures.is_empty(),
        "Disabled cached construction did not revalidate the active cache: {}",
        failures.join("; ")
    );
}

/// **Invariant I4.OnnxEmbedder.lazy-disabled-uncached**: a *lazy*
/// embedder (`new_lazy_with_options`) constructed under
/// `NetworkPolicy::Disabled` for an uncached model MUST succeed at
/// construction (nothing is loaded yet) and MUST surface
/// `EmbeddingError::Network` at the first `embed()` call — the same
/// policy gate as the eager constructor, deferred to first use. A
/// denied load MUST NOT leave a partial-download artifact and MUST NOT
/// be cached as a permanent failure (the pool stays unbuilt, so a later
/// call under a permissive environment can retry).
///
/// Mechanical proof:
///   1. Point `FASTEMBED_CACHE_DIR` at a fresh tempdir — guarantees the
///      model is NOT cached.
///   2. `new_lazy_with_options(<model>, &Disabled, 1)` returns `Ok` and
///      reports the correct dimensionality without loading anything.
///   3. `embed("hello")` returns `Err(EmbeddingError::Network(_))`.
///   4. The cache tempdir has no `models--*` subdirectory.
#[test]
fn onnx_embedder_lazy_under_disabled_with_uncached_model_errors_at_first_use() {
    let _ = real_cache_dir();
    let _serial = cache_env_lock().lock().expect("env lock poisoned");

    let cache_tempdir = TempDir::new().expect("tempdir for empty fastembed cache");
    let _guard = FastembedCacheGuard::set(cache_tempdir.path());

    let embedder = OnnxEmbedder::new_lazy_with_options(
        "Alibaba-NLP/gte-base-en-v1.5",
        &NetworkPolicy::Disabled,
        1,
    )
    .expect("lazy construction must succeed without loading the model");
    assert_eq!(
        embedder.dimensions(),
        768,
        "dimensions must be available before the model is loaded"
    );

    match embedder.embed("hello") {
        Err(EmbeddingError::Network(msg)) => {
            assert!(
                msg.contains("Disabled") || msg.contains("not permitted"),
                "expected Disabled-policy error message, got: {msg}"
            );
        }
        Err(other) => panic!(
            "expected EmbeddingError::Network at first use for uncached model \
             under Disabled, got {other:?}"
        ),
        Ok(_) => panic!(
            "lazy embed succeeded under Disabled with empty cache — \
             the deferred load-time policy gate did not fire"
        ),
    }

    // No partial download artifact: the policy gate fires BEFORE
    // fastembed's `pull_from_hf` is invoked, even on the lazy path.
    let entries: Vec<_> = std::fs::read_dir(cache_tempdir.path())
        .expect("read tempdir")
        .filter_map(Result::ok)
        .filter(|e| e.file_name().to_string_lossy().starts_with("models--"))
        .collect();
    assert!(
        entries.is_empty(),
        "expected no model subdirectory after denied lazy load, found: {entries:?}"
    );
}

// -------------------------------------------------------------------------
// FASTEMBED_CACHE_DIR env-var guard
// -------------------------------------------------------------------------

/// RAII guard that pins `FASTEMBED_CACHE_DIR`, clears the higher-precedence
/// `HF_HOME`, and points `HF_ENDPOINT` at a closed loopback port for the
/// duration of a test. It also pins the embedding pool to one session so real
/// model fixtures stay bounded. All four previous values are restored on drop.
/// Used by the `Disabled`-policy tests above to control whether the model
/// appears cached while ensuring a regression cannot reach the public hub.
///
/// `# Safety`: `std::env::set_var`/`remove_var` are flagged unsafe in
/// modern Rust because env mutation is process-global and not
/// thread-safe. Tests in this file that touch the cache dir are
/// designed to run sequentially within one cargo-test binary; if
/// future tests are added that touch other env vars in parallel, they
/// must coordinate via a shared mutex or `serial_test`.
struct FastembedCacheGuard {
    cache_dir: Option<String>,
    hf_home: Option<String>,
    hf_endpoint: Option<String>,
    embedding_pool_size: Option<String>,
}

#[allow(
    unsafe_code,
    reason = "test-only env-var guard; std::env::set_var/remove_var require unsafe in modern Rust because env mutation is process-global. Tests using this guard run sequentially within one cargo-test binary (see struct doc)."
)]
impl FastembedCacheGuard {
    fn set(path: &std::path::Path) -> Self {
        let previous_cache_dir = std::env::var("FASTEMBED_CACHE_DIR").ok();
        let previous_hf_home = std::env::var("HF_HOME").ok();
        let previous_hf_endpoint = std::env::var("HF_ENDPOINT").ok();
        let previous_embedding_pool_size = std::env::var("PENSYVE_EMBEDDING_POOL_SIZE").ok();
        // SAFETY: see struct doc — tests using this guard run sequentially.
        unsafe {
            std::env::set_var("FASTEMBED_CACHE_DIR", path);
            std::env::remove_var("HF_HOME");
            std::env::set_var("HF_ENDPOINT", "http://127.0.0.1:9");
            std::env::set_var("PENSYVE_EMBEDDING_POOL_SIZE", "1");
        }
        Self {
            cache_dir: previous_cache_dir,
            hf_home: previous_hf_home,
            hf_endpoint: previous_hf_endpoint,
            embedding_pool_size: previous_embedding_pool_size,
        }
    }
}

#[allow(
    unsafe_code,
    reason = "test-only env-var guard; see set() impl above for justification"
)]
impl Drop for FastembedCacheGuard {
    fn drop(&mut self) {
        // SAFETY: see struct doc.
        unsafe {
            match self.cache_dir.as_deref() {
                Some(v) => std::env::set_var("FASTEMBED_CACHE_DIR", v),
                None => std::env::remove_var("FASTEMBED_CACHE_DIR"),
            }
            match self.hf_home.as_deref() {
                Some(v) => std::env::set_var("HF_HOME", v),
                None => std::env::remove_var("HF_HOME"),
            }
            match self.hf_endpoint.as_deref() {
                Some(v) => std::env::set_var("HF_ENDPOINT", v),
                None => std::env::remove_var("HF_ENDPOINT"),
            }
            match self.embedding_pool_size.as_deref() {
                Some(v) => std::env::set_var("PENSYVE_EMBEDDING_POOL_SIZE", v),
                None => std::env::remove_var("PENSYVE_EMBEDDING_POOL_SIZE"),
            }
        }
    }
}

// -------------------------------------------------------------------------
// PeerCard — pure SQLite read-only
// -------------------------------------------------------------------------

/// **Invariant I4.PeerCard**: `build_peer_card(db_path)` MUST open the
/// SQLite store with `SQLITE_OPEN_READ_ONLY` flags and MUST NOT make
/// any network request. Per pre-reg §2 I4: "pure SQLite read-only
/// (`SQLITE_OPEN_READ_ONLY` at `peer_card.rs:56-60`). G1 invariant:
/// documented no-op; no policy parameter required."
///
/// Mechanical proof:
///   1. Build a peer card against a tempdir SQLite store. Assert the
///      call returns `Some(card)` — proves the read-only flag does
///      not block the SELECT.
///   2. Acquire a separate read-only connection to the same store and
///      attempt a write. Assert the write fails with a SQLite "readonly
///      database" error — proves that opening with
///      `SQLITE_OPEN_READ_ONLY` enforces the read-only contract for
///      that handle. (This does NOT prove `build_peer_card` itself uses
///      the flag — that is verified by direct source inspection of
///      `peer_card.rs:56-60`. What it DOES prove is that the underlying
///      SQLite primitive `OpenFlags::SQLITE_OPEN_READ_ONLY` works as
///      advertised, so the production-code line that uses it has the
///      effect we attribute to it.)
///   3. Import-hygiene guard at top of file applies — no HTTP-client
///      crate is imported, and the production `peer_card.rs` only
///      depends on `rusqlite` (verified by reading the file's `use`
///      block at draft time).
#[test]
fn peer_card_uses_only_readonly_sqlite_no_network() {
    let dir = TempDir::new().expect("tempdir");
    let db_path = dir.path().join("test_peer_card.db");

    // Step 1: bootstrap a minimal observation_memories table and write
    // a preference row. Use a writable connection that is dropped
    // before the peer-card builder runs — the builder only ever opens
    // the file with read-only flags.
    {
        let conn = Connection::open(&db_path).expect("open writable conn");
        conn.execute(
            "CREATE TABLE observation_memories (
                id INTEGER PRIMARY KEY,
                action TEXT,
                instance TEXT,
                entity_type TEXT,
                content TEXT,
                event_time TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )",
            [],
        )
        .expect("create table");
        conn.execute(
            "INSERT INTO observation_memories (action, content, event_time) \
             VALUES ('prefers', 'no-network coffee shops', '2026-05-05')",
            [],
        )
        .expect("seed preference row");
    }

    // Step 2: build the peer card. This invokes the read-only open
    // path at `peer_card.rs:56-60`. If the production code ever
    // regresses to a writable open (or worse, opens a network
    // connection), this call site is the one most likely to surface
    // the regression because it's exercised on every recall.
    let card = build_peer_card(&db_path).expect("peer card should build from seeded store");
    assert!(
        card.starts_with(PEER_CARD_HEADER),
        "card should have header"
    );
    assert!(card.ends_with(PEER_CARD_FOOTER), "card should have footer");
    assert!(
        card.contains("PREFERENCE: no-network coffee shops"),
        "card should contain seeded preference"
    );

    // Step 3: prove that `SQLITE_OPEN_READ_ONLY` actually denies writes.
    // We reopen the file with the same flags `peer_card.rs` uses and
    // attempt a no-op INSERT — it must fail.
    let ro_conn = Connection::open_with_flags(
        &db_path,
        rusqlite::OpenFlags::SQLITE_OPEN_READ_ONLY | rusqlite::OpenFlags::SQLITE_OPEN_NO_MUTEX,
    )
    .expect("reopen read-only");
    let write_attempt = ro_conn.execute(
        "INSERT INTO observation_memories (action, content) VALUES ('prefers', 'should fail')",
        [],
    );
    assert!(
        write_attempt.is_err(),
        "SQLITE_OPEN_READ_ONLY connection MUST reject writes; \
         got Ok(...) which means the read-only contract is broken"
    );
    let err_msg = write_attempt.unwrap_err().to_string().to_lowercase();
    assert!(
        err_msg.contains("readonly")
            || err_msg.contains("read-only")
            || err_msg.contains("read only"),
        "expected a readonly-database error, got: {err_msg}"
    );

    // Step 4: confirm the build_peer_card call did not mutate the
    // store. Row count after = row count before = 1.
    let count: i64 = Connection::open(&db_path)
        .expect("reopen writable to count")
        .query_row("SELECT COUNT(*) FROM observation_memories", [], |row| {
            row.get(0)
        })
        .expect("count rows");
    assert_eq!(count, 1, "build_peer_card must not insert/delete rows");
}
